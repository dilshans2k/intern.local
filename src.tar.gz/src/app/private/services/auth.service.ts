import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NULL_EXPR } from '@angular/compiler/src/output/output_ast';
import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { lastValueFrom, Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { tokenGetter } from 'src/app/app.module';
import { LoginResponseI } from 'src/app/model/login-response';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor(private http: HttpClient, private snackbar: MatSnackBar) {}

  token = localStorage.getItem('token');
  error = false;
  dataa = {};

  addHeaders(token: string | null) {
    return {
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + token,
    };
  }

  requestOptions(token: string | null) {
    return { headers: new HttpHeaders(this.addHeaders(token)) };
  }

  headerDict = {
    'Content-Type': 'application/json',
    Authorization: 'Bearer ' + this.token,
  };
  // requestOptions = { headers: new HttpHeaders(this.addHeaders(this.token)) };
  headers = new HttpHeaders(this.headerDict);
  // isLoggedIn() {
  //   if (this.token != null) {
  //     this.http
  //       .get('http://127.0.0.1:3000/profile', this.requestOptions)
  //       .subscribe((error) => {
  //         (this.error = true), console.log(error);
  //       });
  //     if (this.error) {
  //       return false;
  //     } else {
  //       console.log('error');
  //       return true;
  //     }
  //   } else {
  //     console.log('No token');
  //     return false;
  //   }
  // }

  isvalid = false;

  async isLoggedIn() {
    const token = localStorage.getItem('token');
    if (token != null) {
      await fetch('http://127.0.0.1:3000/profile', {
        headers: this.addHeaders(token),
        method: 'GET',
      }).then(async (response) => {
        const isJson = response.headers
          .get('content-type')
          ?.includes('application/json');
        const data = isJson ? await response.json() : null;
        if (!response.ok) {
          const error = (data && data.message) || response.status;
          this.isvalid = false;
          console.log('error', error);
          return;
        }
        console.log('1');
        this.isvalid = true;
      });
    } else {
      console.log('3');
      this.isvalid = false;
      // return false;
    }
  }

  isLoggedIn1() {
    console.log(this.isvalid);
    return this.isvalid;
  }

  async autoLogin(): Promise<boolean> {
    const token = localStorage.getItem('token');
    try {
      console.log('tok', this.token);
      const resp = await lastValueFrom(
        this.http.get(
          'http://127.0.0.1:3000/profile',
          this.requestOptions(token)
        )
      );
      console.log(resp);
      return true;
    } catch (err) {
      console.log('eorrr');
      localStorage.removeItem('token');
      return false;
    }
  }
}
