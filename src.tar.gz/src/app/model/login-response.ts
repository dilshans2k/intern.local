export interface LoginResponseI {
  accessToken: string;
  id?: string;
  uname?: string;
}
